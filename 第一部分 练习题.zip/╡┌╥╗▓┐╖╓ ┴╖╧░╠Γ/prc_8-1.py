# python 案例入门与实践
# 创建时间：2022/7/27 15:29
def favorite_book(title):
    """你最喜欢的书籍名称。"""
    print(f"one of my favorite book is{title}")
favorite_book('基督山伯爵')