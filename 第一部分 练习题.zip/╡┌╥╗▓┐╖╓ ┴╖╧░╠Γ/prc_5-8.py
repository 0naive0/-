# python 案例入门与实践
# 创建时间：2022/7/25 15:51
user_names = ['John', 'admin', 'Tom','naive', 'michale']
for user_name in user_names:
    if user_name == 'admin':
        print("Hello admin, would you like to see a status report?")
    elif user_name == 'Tom':
            print("Hello TOM, thank you for logging in again")
    else:
        print(f"Hello {user_name}, thank you for logging in again.")
