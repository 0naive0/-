# python 案例入门与实践
# 创建时间：2022/7/27 11:05
age = input("请输入您的年龄")
age = int (age)
if age <= 3:
    print("free")
elif age > 3 and age <= 12 :
    print( "10 dollar")
else:
    print("12 dollars")