# python 案例入门与实践
# 创建时间：2022/7/27 10:43
additon = "\n请输入您想添加的配料："
message = ""
active = 'true'
while message != 'quit':
    message = input(additon)
if message != 'quit ':
    active = 'flase'
else:
    print(f"我们会在配料中添加{message}")
