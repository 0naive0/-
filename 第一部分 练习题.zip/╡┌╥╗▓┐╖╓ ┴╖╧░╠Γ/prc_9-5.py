# python 案例入门与实践
# 创建时间：2022/7/28 10:33
class User():
    def __init__(self, first_name, last_name,age):
        self.first_name = first_name
        self.last_name = last_name
        self.age = age
    def describe_user(self):
        msg = f"{self.first_name},{self.last_name} is {self.age} years old"
        print(f"\n{msg}")
    def greet_user(self):
        msg = f"Hello {self.first_name}{self.last_name}"
        print(f"\n{msg}")
    def update_login_attempts(self,login_attempts ):
        self.login_attempts_reading = login_attempts
uesr = User('li','shiyu','18')
uesr.describe_user()
uesr.greet_user()
uesr.update_login_attempts(23)
uesr.read_login_attempts ()