# python 案例入门与实践
# 创建时间：2022/7/27 14:48
sandwich_orders = ['xian','tian','wuxiang']
finished_sandwiches = []
print(sandwich_orders)
while 'sandwich_order' in sandwich_orders:
    print(f"i made your {sandwich_orders}sandwich")