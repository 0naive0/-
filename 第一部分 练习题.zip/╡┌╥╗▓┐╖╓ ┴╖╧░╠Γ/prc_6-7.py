# python 案例入门与实践
# 创建时间：2022/7/26 20:51
lsy = {'first_name' :'li','lase_name' : 'shiyu','age' : '18' , 'city' : 'wuhan'}
lsx = {'first_name' :'li','lase_name' : 'songxun','age' : '18' , 'city' : 'shiyan'}
zzh = {'first_name' :'zhang','lase_name' : 'zhihui','age' : '18' , 'city' : 'hunan'}
peoples = [lsy,lsx,zzh]
for people in peoples :
    print(people)