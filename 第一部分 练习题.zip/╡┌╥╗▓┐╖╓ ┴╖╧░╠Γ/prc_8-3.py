# python 案例入门与实践
# 创建时间：2022/7/27 15:49
def make_shirt(size,type):
    """说明T恤的尺码和字样。"""
    print(f"您预定的T恤的尺码是{size}，类型是{type}")
make_shirt(size = 'large',type = 'love')
make_shirt(size = 'M',type = 'peace')