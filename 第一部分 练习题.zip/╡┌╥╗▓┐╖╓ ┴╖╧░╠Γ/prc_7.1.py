# python 案例入门与实践
# 创建时间：2022/7/27 10:09
message = input("你想要租用什么车:")
print(f"\n Let me see if i can fing you a {message}.")