# python 案例入门与实践
# 创建时间：2022/7/26 20:21
lsy = {'first_name' :'li','lase_name' : 'shiyu','age' : '18' , 'city' : 'wuhan'}
for k,v in lsy.items():
    print(f"k:{k}")
    print(f"v:{v}")
