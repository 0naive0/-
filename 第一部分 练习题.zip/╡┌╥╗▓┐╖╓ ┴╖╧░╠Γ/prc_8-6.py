# python 案例入门与实践
# 创建时间：2022/7/28 9:09
def city_country(city,country):
    full_name = f"{city},{country}"
    return full_name.title()
name = city_country('xiangyang','hubei')
print(name)