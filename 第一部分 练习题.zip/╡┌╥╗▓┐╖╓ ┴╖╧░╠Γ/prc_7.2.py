# python 案例入门与实践
# 创建时间：2022/7/27 10:12
people = input("how many people will order the resturant")
people = int(people)
if people >= 8:
    print("there are not enough seats")
else:
    print("there have enough seats")