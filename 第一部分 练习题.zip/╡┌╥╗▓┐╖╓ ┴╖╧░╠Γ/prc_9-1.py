# python 案例入门与实践
# 创建时间：2022/7/28 9:23
class Resturant():
    def __init__(self,name,cuisine_type):
        self.name = name
        self.cuisine_type = cuisine_type
    def describe_resturant(self):
        msg = f"{self.name} serves wonderfull {self.cuisine_type}."
        print(f"\n{msg}")
    def open_resturant(self):
        msg = f"{self.name} is open"
        print(f"\n{msg}")
resturant = Resturant('sxy','Chinese')
print(resturant.name)
print(resturant.cuisine_type)
resturant.describe_resturant()
resturant.open_resturant()