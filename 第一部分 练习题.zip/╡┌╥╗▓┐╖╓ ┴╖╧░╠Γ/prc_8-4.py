# python 案例入门与实践
# 创建时间：2022/7/27 15:57
def make_shirt(size,type = 'I Love Ptyhon'):
    """说明T恤的尺码和字样。"""
    print(f"您预定的T恤的尺码是{size}，类型是{type}")
make_shirt(size='large')
make_shirt(size='medium')
make_shirt(size='large',type='I Love C')